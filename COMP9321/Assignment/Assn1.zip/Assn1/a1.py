'''
COMP9321 Assignment One Code Template 2019T1
Name:
Student ID:
'''

def q1():
    '''
    Put Your Question 1's code in this function
    '''
    pass 

def q2():
    '''
    Put Your Question 2's code in this function 
    '''
    pass 

def q3():
    '''
    Put Your Question 3's code in this function 
    '''
    pass 

def q4():
    '''
    Put Your Question 4's code in this function 
    '''
    pass 

def q5():
    '''
    Bonus Question(Optional).
    Put Your Question 5's code in this function.
    '''
    pass 